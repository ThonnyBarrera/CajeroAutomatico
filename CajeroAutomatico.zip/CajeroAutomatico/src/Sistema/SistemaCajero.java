
package Sistema;

import javax.swing.JOptionPane;


public class SistemaCajero {
    
    //--Variables locales
    public static double saldoActual;
    
    
    //--- Constructor
    public SistemaCajero(){
    saldoActual = 0;
    }
   
   
    //---Metodos
    
    public void depositar(double deposito){
    saldoActual += deposito;
    
    }
    
    public void retirar (double retiro){
    if(saldoActual >= retiro){
        saldoActual -= retiro;
    }
    else{
       JOptionPane.showMessageDialog(null, "[Error] -saldo insuficiente-");
    }
    
    }
    
    public double obtenerSaldo(){
    return saldoActual;
    }
    
}
